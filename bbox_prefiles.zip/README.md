# BBox Utilities

## COCO
<div align=center><img src="https://cocodataset.org/images/coco-logo.png" width=600></div>